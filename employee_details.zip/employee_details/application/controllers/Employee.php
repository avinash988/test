<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Employee extends CI_Controller
{
	function __construct()
	{
        parent::__construct();
        $this->load->model('Employee_Model');
    }

    public function index()
    {
    	$this->load->view("home");
    }

    public function login()
    {
        $this->form_validation->set_rules('email', 'Email Id', 'trim|required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[8]');

        if($this->form_validation->run() == FALSE)
        {
            $this->index();
        }else
        {
            $uname = $this->input->post('email');
            $password = $this->input->post('password');

            if($this->Employee_Model->verify_uname_pwd($uname,$password))
            {
                $data['res'] = $this->Employee_Model->emp_details();
                $this->load->view("employee_details", $data);
            }else
            {
                $this->session->set_flashdata('msg','<div class="alert alert-danger text-center">Oops! Error.  Please register first then try again!!!</div>');
                $this->index();
            }
        }
    }

    public function register_form()
    {
        $this->load->view("registration_form");
    }

    public function register()
    {
        $this->form_validation->set_rules('first_name', 'First Name', 'trim|required|alpha|min_length[2]');
        $this->form_validation->set_rules('last_name', 'First Name', 'trim|required|alpha');
        $this->form_validation->set_rules('email', 'Email Id', 'trim|required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'callback_valid_password');

        if($this->form_validation->run() == FALSE)
        {
            $this->register_form();
        }else
        {
            date_default_timezone_set('Asia/Kolkata');
            $current_date = date('Y-m-d H:i:s');

            $first_name = $this->input->post('first_name');
            $last_name = $this->input->post('last_name');
            $email = $this->input->post('email');
            $password = $this->input->post('password');

            $data = array(
                'first_name'    => $first_name,
                'last_name'     => $last_name,
                'email'         => $email,
                'password'      => $password,
                'added_on'      => $current_date
            ); 

            $insert = $this->Employee_Model->insert_records($data);

            $this->index();
        }
    }

    public function valid_password($password = '')
    {
        $password = trim($password);
        $regex_lowercase = '/[a-z]/';
        $regex_number = '/[0-9]/';
        if (empty($password))
        {
            $this->form_validation->set_message('valid_password', 'The {field} field is required.');

            return FALSE;
        }
        if (preg_match_all($regex_lowercase, $password) < 1)
        {
            $this->form_validation->set_message('valid_password', 'The {field} field must be at least one lowercase letter.');
            return FALSE;
        }
        if (preg_match_all($regex_number, $password) < 1)
        {
            $this->form_validation->set_message('valid_password', 'The {field} field must have at least one number.');
            return FALSE;
        }
        if (strlen($password) < 8)
        {
            $this->form_validation->set_message('valid_password', 'The {field} field must be at least 8 characters in length.');

            return FALSE;
        }
    }

    public function logout()
    {
        $this->index();
    }

}

?>
