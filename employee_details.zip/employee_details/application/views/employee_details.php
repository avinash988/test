<?php $this->load->view('header'); ?>

<body>

<div class="container">
	<div class="row text-right" style="margin-top: 20px;">
  		<h4><a href="<?php echo base_url().'employee/logout'; ?>">Logout</a></h4>
  	</div>
	<div class="row">
		<div class="col-sm-offset-2 col-md-8">
			<h2 class="text-center">Employee Details</h2>
			<table class="table table-bordered">
				<thead>
					<tr>
						<th>First Name</th>
						<th>Last Name</th>
						<th>Email</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach($res as $row){ ?>
					<tr>
						<td><?php echo $row['first_name']; ?></td>
						<td><?php echo $row['last_name']; ?></td>
						<td><?php echo $row['email']; ?></td>
					</tr>
					<?php } ?>
				</tbody>
			</table>
		</div>
	</div>
    
    
</div>

</body>
</html>
