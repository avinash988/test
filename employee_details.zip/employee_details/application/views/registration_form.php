<?php $this->load->view('header'); ?>

<body>

<div class="container">
	<div class="row">
		<div class="col-sm-offset-4 col-md-4 border_style">
			<h2 class="text-center">Employee Registration</h2><br>
			<form class="form-horizontal" method="POST" action="<?php echo base_url().'employee/register'; ?>">
				<div class="form-group">
					<label class="control-label col-sm-4">First Name:</label>
					<div class="col-sm-8">
						<input type="text" class="form-control" placeholder="Enter first name" name="first_name" value="<?=set_value('first_name');?>">
						<small><?php echo form_error('first_name'); ?></small>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-4">Last Name:</label>
					<div class="col-sm-8">
						<input type="text" class="form-control" placeholder="Enter last name" name="last_name" value="<?=set_value('last_name');?>">
						<small><?php echo form_error('last_name'); ?></small>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-4">Email Id:</label>
					<div class="col-sm-8">
						<input type="email" class="form-control" placeholder="Enter email" name="email" value="<?=set_value('email');?>">
						<small><?php echo form_error('email'); ?></small>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-4">Password:</label>
					<div class="col-sm-8">
						<input type="password" class="form-control" placeholder="Enter password" name="password">
						<small><?php echo form_error('password'); ?></small>
					</div>
				</div>
				<div class="text-center">
					<button type="submit" class="btn btn-primary">Submit</button>
				</div>
				<br>
				<div class="text-center">
					<a href="<?php echo base_url().'employee/'; ?>">Back to Login page</a>
				</div>
			</form>			 
		</div>
	</div>
  
</div>

</body>
</html>
