<?php $this->load->view('header'); ?>

<body>

<div class="container">
	<div class="row">
		<div class="col-sm-offset-4 col-md-4 border_style">
			<div>
		        <?php echo $this->session->flashdata('msg'); ?>
		    </div>
			<h2 class="text-center">Employee Login</h2><br>
			<form class="form-horizontal" method="POST" action="<?php echo base_url().'employee/login'; ?>">
				<div class="form-group">
					<label class="control-label col-sm-4" for="email">Email Id:</label>
					<div class="col-sm-8">
						<input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
						<small><?php echo form_error('email'); ?></small>
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-4" for="pwd">Password:</label>
					<div class="col-sm-8">
						<input type="password" class="form-control" placeholder="Enter password" name="password">
						<small><?php echo form_error('password'); ?></small>
					</div>
				</div>
				<div class="text-center">
					<button type="submit" class="btn btn-primary">Submit</button>
				</div>
				<br>
				<div>
					<h5>Don't have an account? <a href="<?php echo base_url().'employee/register_form'; ?>">Registration Now</a></h5>
				</div>
			</form>			 
		</div>
	</div>
  
</div>

</body>
</html>
