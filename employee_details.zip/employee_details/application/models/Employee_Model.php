<?php

class Employee_Model extends CI_Model
{
	
	public function __construct()
	{
		parent::__construct();
	}

	public function insert_records($data)
	{
		$query = $this->db->insert('user_register', $data);
		return $query;
	}

	public function emp_details()
	{
		$query = $this->db->query("SELECT * FROM user_register");
        return $query->result_array();
	}

	public function verify_uname_pwd($uname,$password)
	{
		$query = $this->db->where(['email'=>$uname,'password'=>$password])->get('user_register');
		return $query->result_array();
	}

}
